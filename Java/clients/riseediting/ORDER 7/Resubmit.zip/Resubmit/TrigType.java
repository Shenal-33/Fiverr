enum TrigType {COSINE,SINE}
